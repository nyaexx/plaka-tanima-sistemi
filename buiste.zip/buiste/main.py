import sys
from PySide2.QtWidgets import QApplication, QMainWindow, QStackedWidget, QWidget, QVBoxLayout, QLabel
from PySide2.QtCore import Qt

# UI dosyalarını import edin
from sonuncuarayuz_ui import Ui_SonuncuArayuz  # Sonuncu arayüz UI dosyasını import et
from plakakaydetmesayfasison_ui import Ui_PlakaKaydetmeSayfasiSon  # Plaka ekleme UI dosyasını import et

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("Ana Sayfa")
        
        # Stacked Widget ile sayfalar arası geçişi sağlayacağız
        self.stack = QStackedWidget(self)
        self.setCentralWidget(self.stack)
        
        # UI dosyalarını oluştur
        self.sonuncuarayuz = Ui_SonuncuArayuz()
        self.plakakaydetmesayfasi = Ui_PlakaKaydetmeSayfasiSon()

        # Arayüz sayfalarını stacked widget'a ekle
        self.stack.addWidget(self.sonuncuarayuz)
        self.stack.addWidget(self.plakakaydetmesayfasi)

        # Butonları tanımla
        self.sonuncuarayuz.btn_anasayfa.clicked.connect(self.show_sonuncuarayuz)
        self.sonuncuarayuz.btn_hakkinda.clicked.connect(self.show_hakkinda)
        self.sonuncuarayuz.btn_plakalar.clicked.connect(self.show_plakasayfasi)
        self.plakakaydetmesayfasi.pushButton_2.clicked.connect(self.show_plakaeklemepenceresi)
    
    def show_sonuncuarayuz(self):
        self.stack.setCurrentWidget(self.sonuncuarayuz)
    
    def show_hakkinda(self):
        self.stack.setCurrentWidget(self.hakkinda)

    def show_plakasayfasi(self):
        self.stack.setCurrentWidget(self.plakakaydetmesayfasi)

    def show_plakaeklemepenceresi(self):
        plaka_pencere = PlakaEklemePenceresi()
        plaka_pencere.show()

# Plaka ekleme penceresinin basit bir sınıfı
class PlakaEklemePenceresi(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Plaka Ekle")
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Burada plaka ekleyebilirsiniz."))
        self.setLayout(layout)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
